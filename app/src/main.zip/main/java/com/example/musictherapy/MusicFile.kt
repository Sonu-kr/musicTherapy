package com.example.musictherapy

data class MusicFile(val name: String, val path: String)

